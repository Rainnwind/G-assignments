#ifndef BUENOS_TTY_WRITE_H
#define BUENOS_TTY_WRITE_H

int syscall_write(uint32_t, uint32_t, uint32_t);

#endif