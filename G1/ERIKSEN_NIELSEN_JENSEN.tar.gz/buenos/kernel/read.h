#ifndef BUENOS_TTY_READ_H
#define BUENOS_TTY_READ_H

int syscall_read(uint32_t, uint32_t, uint32_t);

#endif